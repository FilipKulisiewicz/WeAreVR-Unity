using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RosMessageTypes.Geometry;
using Unity.Robotics.ROSTCPConnector.ROSGeometry;
using System;

public class SphereManager : MonoBehaviour
{
    public GameObject sphere;  
    public static event Func<float, float, bool, PositionRotation> TransformRequestFrame;
    public static event Func<float, bool, PositionRotation> TransformRequest;
    public float delay = 0.12f; 
    public float frametime = 1.0f /29.97f; //29.0f; // 29.97f;
    public bool interpolate = true;
    
    private void OnEnable(){
        //CameraCallbackExample.newFrame += Unwind;
        WebCamDetect.newFrame += Unwind;
    }
    private void OnDisable(){
        //CameraCallbackExample.newFrame -= Unwind;
        WebCamDetect.newFrame -= Unwind;
    }
    
    private float requestedTime = 0.0f;
    private float lastFrame = 0.0f;
    private float lastFrameUnityTime = 0.0f;
    private float timeDiff;
    private PositionRotation fromBuffer;

    public void Unwind(){
        if(Time.time < 10.0f){ //old unwinding
            fromBuffer = (PositionRotation)TransformRequest?.Invoke(delay, interpolate);
            lastFrame = Time.time;
        }
        else{ //framerate based unwinding
            requestedTime = lastFrame + frametime;
            if(Time.time - requestedTime > 0.035f || Time.time - requestedTime < -0.035f){
                Debug.Log("pre: " + (Time.time - requestedTime));
                if(Time.time - requestedTime > 0){
                    Debug.Log("+f");
                    requestedTime = requestedTime + frametime; 
                }
                else{
                    Debug.Log("-f");
                    requestedTime = requestedTime - frametime;
                }
            }
            
            // if(Time.time - lastFrameUnityTime > 0.055){ //skiped frame
            //     requestedTime = lastFrame + frametime * 2;            
            // }
            // else{ 
            //     requestedTime = lastFrame + frametime;
            // }
            fromBuffer = (PositionRotation)TransformRequestFrame?.Invoke(requestedTime, delay , interpolate);
            lastFrame = requestedTime;
            //Debug.Log("Time.time:" + Time.time);
            //Debug.Log("requestedTime:" + requestedTime);
            //Debug.Log((Time.time - lastFrameUnityTime));
            //Debug.Log((Time.time - requestedTime)); 
        }
        lastFrameUnityTime = Time.time;
        sphere.transform.rotation = fromBuffer.rotation;
    }
}

